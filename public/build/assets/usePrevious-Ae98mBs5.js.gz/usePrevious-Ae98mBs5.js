import{b as e}from"./index-Drr-5sAG.js";function f(t){var r=e.useRef();return e.useEffect(function(){r.current=t}),r.current}export{f as u};
