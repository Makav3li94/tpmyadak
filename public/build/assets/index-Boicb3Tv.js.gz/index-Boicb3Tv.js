import{i as r}from"./index-Drr-5sAG.js";import{r as p}from"./index-Chjiymov.js";var o=p();const t=r(o);export{t as P,o as p};
