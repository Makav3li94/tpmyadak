import{h as a}from"./textarea-input-CD_7fYAM.js";import{u as i}from"./error-baundry-BidbxAZT.js";function m({p:s,children:o}){const{props:{auth:r}}=i();if(a(r,s))return o}export{m as H};
