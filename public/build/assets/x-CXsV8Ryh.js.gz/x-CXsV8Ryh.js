import{c as o}from"./createLucideIcon-DdzWq45B.js";const c=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],t=o("x",c);export{t as X};
