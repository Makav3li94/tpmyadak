import{h as a}from"./textarea-input-D1X_UlTc.js";import{u as i}from"./index-DDca1aiV.js";function m({p:s,children:o}){const{props:{auth:r}}=i();if(a(r,s))return o}export{m as H};
