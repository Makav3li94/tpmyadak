import{h as a}from"./textarea-input-nUcVDi94.js";import{u as i}from"./index-Drr-5sAG.js";function m({p:s,children:o}){const{props:{auth:r}}=i();if(a(r,s))return o}export{m as H};
