const e={text:"Text",textarea:"Text Area",date:"Date",select:"Select",checkbox:"Checkbox",multiple:"Multiple Choice"},t={yes:"Yes",no:"No"};export{e as I,t as R};
