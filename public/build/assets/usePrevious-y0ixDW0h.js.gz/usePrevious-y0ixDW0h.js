import{b as e}from"./error-baundry-BidbxAZT.js";function f(t){var r=e.useRef();return e.useEffect(function(){r.current=t}),r.current}export{f as u};
